ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName = "Ruisu's Capture System | Flag"
ENT.Author = "Ruisu"
ENT.Category = "Ruisu's Capture System"
ENT.Contact = "no!"
ENT.Instructions = "why are u looking here"
ENT.Spawnable = false
ENT.AdminSpawnable = false