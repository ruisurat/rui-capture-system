AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

include("shared.lua");

function ENT:Initialize()
    self:SetModel("models/gmodflags/otherflagpole.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetModelScale( 0.3 )
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    
    local phys = self:GetPhysicsObject()
    if (phys && IsValid(phys)) then
        phys:Sleep()
        phys:EnableMotion(false)
        phys:SetMass(10)
    end

    self:SetColor(Color(255, 255, 255, 0))
    self:SetMaterial("phoenix_storms/gear")
    self:DrawShadow(true)
    self:SetNWFloat("team",0)
    self:SetNWFloat("captureprogress",0)
    self:SetNWFloat("name", "A")
    self.LastThink = rcs.config.tick
end

function ENT:Think()
    if( self.LastThink > CurTime() ) then
        return;
    end
    
    local teams = {};
    teams[ 1 ] = {};
    teams[ 2 ] = {};
    for i, v in pairs( player.GetAll() ) do
        if( v:GetPos():Distance( self:GetPos() ) < rcs.config.pointsize ) then
            if( rcs.config.teams[ team.GetName( v:Team() ) ] && v:Alive() ) then
                table.insert( teams[ rcs.config.teams[ team.GetName( v:Team() ) ] ], true );
            end
        end
    end
    
    local add = true;
    local count		 = 0;
    if( table.Count( teams[ 1 ] ) > table.Count( teams[ 2 ] ) ) then
        count = table.Count( teams[ 1 ] ) - table.Count( teams[ 2 ] );
        
        if( self:GetNWFloat( "team", 0 ) != 1 ) then
            self:SetNWFloat( "progress", math.Clamp( self:GetNWFloat( "progress", 0 ) - count, 0, 100 ) );
            if( self:GetNWFloat( "progress", 0 ) < 1 ) then
                self:SetNWFloat( "team", 1 );
            end
        else
            self:SetNWFloat( "progress", math.Clamp( self:GetNWFloat( "progress", 0 ) + count, 0, 100 ) );
            for k, v in pairs(player.GetAll()) do
                if(v:GetPos():Distance(self:GetPos()) < rcs.config.pointsize) then
                    if(teams[ rcs.config.teams[ team.GetName( v:Team() ) ] ] && v:Alive() ) then
                        if self:GetNWFloat("progress") < 100 then
                            v:addMoney(rcs.config.moneypertick)
                        end
                    end
                end
            end
        end
    elseif( table.Count( teams[ 1 ] ) < table.Count( teams[ 2 ] ) ) then
        count = table.Count( teams[ 2 ] ) - table.Count( teams[ 1 ] );
        if( self:GetNWFloat( "team", 0 ) != 2 ) then
            self:SetNWFloat( "progress", math.Clamp( self:GetNWFloat( "progress", 0 ) - count, 0, 100 ) );
            if( self:GetNWFloat( "progress", 0 ) < 1 ) then
                self:SetNWFloat( "team", 2 );
            end
        else
            self:SetNWFloat( "progress", math.Clamp( self:GetNWFloat( "progress", 0 ) + count, 0, 100 ) );
            for k, v in pairs(player.GetAll()) do
                if(v:GetPos():Distance(self:GetPos()) < rcs.config.pointsize) then
                    if(teams[ rcs.config.teams[ team.GetName( v:Team() ) ] ] && v:Alive() ) then
                        if self:GetNWFloat("progress") < 100 then
                            v:addMoney(rcs.config.moneypertick)
                        end
                    end
                end
            end
        end
    end

    self.LastThink = CurTime() + rcs.config.tick;
end