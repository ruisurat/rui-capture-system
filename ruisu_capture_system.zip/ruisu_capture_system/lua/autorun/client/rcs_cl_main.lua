surface.CreateFont("RCSFont1", {
    font = "Futura Book",
    size = 32,
    weight = 0
} )

surface.CreateFont("RCSFont2", {
    font = "Arial",
    size = 54,
    weight = 0
} )

surface.CreateFont("RCSFont3", {
    font = "Futura Book",
    size = 32,
    weight = 0
} )

surface.CreateFont("RCSFont4", {
    font = "Futura Book",
    size = 64,
    weight = 0
} )

hook.Add("PostDrawTranslucentRenderables", "RCSCreateZone", function()
    for i, v in pairs(ents.FindByClass("capture_flag")) do
        local pos = v:GetPos()
        local ang = v:GetAngles()

        if(!rcs.config.drawconstant && LocalPlayer():GetPos():Distance(pos) > rcs.config.drawdistance) then
            continue
        end

        pos = pos
        pos = pos - Vector(0, 0, -1)

        local curTeam = tonumber(v:GetNWFloat("team",0))
        local prog = tonumber(v:GetNWFloat("progress",0))

        local color = rcs.config.colors.uncaptured
        if (curTeam != 0) then
            color = table.Copy(rcs.config.teams[curTeam].color)
            color.a = 30 + prog * 1.5
        end

        cam.Start3D2D( pos, ang, 1)
            surface.SetDrawColor(color)
            draw.NoTexture()
            draw.Circle(0,0,rcs.config.pointsize, rcs.config.smoothness)
        cam.End3D2D()
    end
end)

hook.Add("HUDPaint", "RCSDrawHUD", function()
    local active = false

    for i, v in pairs(ents.FindByClass("capture_flag")) do
        local pos = v:GetPos()
        local ang = v:GetAngles()
        local zone = v:GetNWString("name", "A")

        local curTeam = v:GetNWFloat("team", 0)
        local clr = rcs.config.colors.contestbar

        if (curTeam != 0) then
            clr = table.Copy( rcs.config.teams[curTeam].color)
        end
        if (v:GetPos():Distance(LocalPlayer():GetPos() ) < rcs.config.pointsize) then
            active = v 
        else
            if (!rcs.config.drawconstant && LocalPlayer():GetPos():Distance(pos) > rcs.config.drawdistance) then
                continue
            end
            local drawNameOnly = false

            pos = pos + Vector(0, 0, 200)
            pos = pos:ToScreen()
            surface.SetFont("RCSFont2")
            local txtW, txtH = surface.GetTextSize(zone)
            draw.SimpleText(zone, "RCSFont2", pos.x - (txtW / 2), pos.y-txtH/2, clr)
            surface.DrawCircle( pos.x, pos.y, 30, clr)
        end
    end

    if (active) then
        local curTeam = tonumber(active:GetNWFloat("team", 0))
        local prog = tonumber(active:GetNWString("progress", 0))
        
        local clr = rcs.config.colors.contestbar
        if (curTeam != 0) then
            clr = table.Copy(rcs.config.teams[curTeam].color)
        end

        local fullW = ScrW() / 2 - 120
        local h = 2.5
        local w = fullW / 2
        local x = ScrW() / 2 - w / 2
        local y = 150
        local barH = 7

        local zone = active:GetNWFloat("name", "A")
        local subname = active:GetNWFloat("subname", "Preset")

        local x = ScrW() / 2
        surface.SetFont("RCSFont2")
        local txtW, txtH = surface.GetTextSize(zone)
        draw.SimpleText(zone, "RCSFont2", x - txtW / 2, y - txtH / 2 - 1, clr)
        clr = rcs.config.colors.contestbar
        surface.DrawCircle(x, y, rcs.config.lettercirclesize, clr)
        surface.DrawCircle(x, y, rcs.config.lettercirclesize-1, clr)
        surface.DrawCircle(x, y, rcs.config.lettercirclesize-2, clr)
        
        surface.SetFont("RCSFont1")
        txtW, txtH = surface.GetTextSize(rcs.config.teams[1].name)
        surface.SetFont("RCSFont4")
        local txtW, txtH = surface.GetTextSize(subname)

        local subclr = table.Copy(rcs.config.colors.contestbar)
        subclr.a = 255
        draw.SimpleText( subname, "RCSFont2", ScrW() / 2 - txtW/2, y + rcs.config.lettercirclesize, subclr)

        x = x - rcs.config.lettercirclesize - w
        y = y + 5
        draw.RoundedBox(0, x, y-15, w, 20, Color(0, 0, 0, 150))
        draw.SimpleText( rcs.config.teams[1].name, "RCSFont1", x, y - 50, rcs.config.teams[1].color)

        if (curTeam == 1) then
            local tick = (w / 100) * prog
            local barClr = table.Copy(rcs.config.teams[1].color)
            barClr.a = rcs
            draw.RoundedBox(0, x+w-tick, y-15, tick, 20, barClr)
        end

        txtW, txtH = surface.GetTextSize(rcs.config.teams[2].name)
        x = ScrW() / 2 + rcs.config.lettercirclesize
        y = y + 5
        draw.RoundedBox(0, x, y-20, w, 20, Color(0, 0, 0, 150))
        if (curTeam == 2) then
            local tick = (w/100) * prog
            local barClr = table.Copy(rcs.config.teams[2].color)
            barClr.a = 185
            draw.RoundedBox(0, x, y-20, tick, 20, barClr)
        end
        x = x + w - txtW
        y = y - txtH
        draw.SimpleText(rcs.config.teams[2].name, "RCSFont1", x, y-20, rcs.config.teams[2].color)
    end
end)