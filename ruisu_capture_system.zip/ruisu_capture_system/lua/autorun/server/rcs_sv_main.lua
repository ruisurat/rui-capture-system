resource.AddFile("fonts/Futura.ttf")

rcs.zones = {}
hook.Add("InitPostEntity", "rcsload", function()
    if (file.Exists("rcs_" .. game.GetMap() .. "_capture_points.txt", "DATA")) then
        rcs.zones = util.JSONToTable(file.Read("rcs_" .. game.GetMap() .. "_capture_points.txt"))
        MsgC(Color(0, 255, 0), "\n"..(table.Count(rcs.zones)) .. "zones were found\n")

        rcsspawnzones()
    end
end)

function rcsspawnzones()
    for i, v in pairs(ents.FindByClass("capture_flag")) do
        v:Remove()
    end

    for i, v in pairs(rcs.zones) do
        local _e = ents.Create("capture_flag")
        _e:Spawn()
        _e:SetPos(v.pos)
        _e:SetAngles(v.ang)
        _e:SetNWString("name", v.name)
        _e:SetNWString("subname", v.subname)
    end
end

hook.Add("PlayerSay", "rcssave", function(_p, msg, _)
    if (string.find(msg, rcs.config.createcommand) && table.HasValue(rcs.config.commandaccess, _p:GetUserGroup())) then
        local pos = _p:GetPos() + Vector(0,0,7)
        local ang = _p:GetAngles()
        local name = string.Replace(msg, rcs.config.createcommand .. " ", "")
        local subname = name
        name = string.sub(name, 0, 1)
        subname = string.sub(subname, 2)

        MsgC(Color(0, 255, 0), "\nCreated new zone | " .. name .. "\n\n")
        table.insert(rcs.zones, {pos = pos, ang = ang, name = name, subname = subname})
        file.Write("rcs_"..game:GetMap() .. "_capture_points.txt", util.TableToJSON(rcs.zones))
        rcsspawnzones()
    elseif(string.find(msg, rcs.config.deletecommand) && table.HasValue(rcs.config.commandaccess, _p:GetUserGroup())) then
        local name = string.Replace(msg, rcs.config.deletecommand .. " ", "")
        for i, v in pairs(rcs.zones) do
            if(v.name == name) then
                rcs.zones[i] = nil
            end
        end

        MsgC(Color(0, 255, 0), "\nDeleted zone | " .. name .. "\n\n")
        file.Write("rcs_"..game:GetMap() .. "_capture_points.txt", util.TableToJSON(rcs.zones))
        rcsspawnzones()
    end
end)