-- do not touch --
rcs = rcs or {}
rcs.config = {}
rcs.config.teams = {}
rcs.config.colors = {}
-- do not touch --

-- Assign your teams here
rcs.config.teams[1] = {
    name = "Team 1",
    color = Color(44, 44, 84)
}

rcs.config.teams[2] = {
    name = "Team 2",
    color = Color(179, 57, 57)
}

---- assign jobs to teams
rcs.config.teams["Citizen"] = 1
rcs.config.teams["Policeman"] = 2

-- How often should progress be checked?
rcs.config.tick = 1

-- Other point settings
rcs.config.pointsize = 200
rcs.config.moneypertick = 15
rcs.config.createcommand = "/createpoint" -- /createpoint [Abbreviation] [Point Name] (MAKE SURE EACH ABBREVIATION IS UNIQUE)
rcs.config.deletecommand = "/deletepoint" -- /deletepoint [Abbreviation]
rcs.config.commandaccess = {"superadmin"} -- determine which staff ranks have access

-- Client Settings
if(CLIENT) then
    rcs.config.drawconstant = false -- determines whether the hud of a capture point should be displayed constantly or not
    rcs.config.drawdistance = 2000 -- how far before it stops drawing?

    -- other settings
    rcs.config.colors.uncaptured = Color(255, 255, 255, 50)
    rcs.config.colors.contestbar = Color(255, 255, 255, 190);
    rcs.config.thickness = 15;
    rcs.config.smoothness = 300;
    rcs.config.lettercirclesize = 30;

    -- don't touch this unless you know what you're doing - may break addon
	function draw.Circle( x, y, radius, seg )
		local cir = {}

		table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
		for i = 0, seg do
			local a = math.rad( ( i / seg ) * -360 )
			table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
		end

		local a = math.rad( 0 )
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

		surface.DrawPoly( cir )
    end	
end